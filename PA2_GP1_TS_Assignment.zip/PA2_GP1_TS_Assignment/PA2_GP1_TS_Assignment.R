###----------------------------------------------------------###
### PA-II - TS Analysis Assignment - Retail Giant Case Study ###
###----------------------------------------------------------###


## LOAD REQUIRED LIBRARY
library("ggplot2")
library("forecast")
library("graphics")
library("tseries")
library("dplyr")
library("plyr")
library("raster")

## LOAD THE DATA
rm(list = ls())
superstore = read.csv("Global Superstore.csv", stringsAsFactors = F)
str(superstore)

## TREAT DUPLICATES
## No duplicate rows found
sum(duplicated(superstore)) # No duplicate rows

## TREAT MISSING VALUES
# "Postal.Code" has NAs, leaving NA's as is, no visible impact
colnames(superstore)[colSums(is.na(superstore)) > 0]

## TREAT CATEGORICAL VARIABLES, CONVERT TO FACTOR TYPE
superstore$Market = as.factor(superstore$Market)
superstore$Segment = as.factor(superstore$Segment)
str(superstore)
summary(superstore$Market)
levels(superstore$Market)      # "APAC"   "Africa" "Canada" "EMEA"   "EU"     "LATAM"  "US"
summary(superstore$Segment)
levels(superstore$Segment)     # "Consumer"    "Corporate"   "Home Office"

# Convert Order.Date and Ship.Date to DATE type
# Derive 2 new columns Order.Month and Elapsed.Month
superstore$Order.Date = as.Date(superstore$Order.Date,format="%d-%m-%Y")
superstore$Order.Month = as.numeric(format(as.Date(superstore$Order.Date), "%Y%m"))
superstore$Ship.Date = as.Date(superstore$Ship.Date,format="%d-%m-%Y")
superstore$Elapsed.Months = superstore$Order.Month - 201100
superstore$Elapsed.Months = floor(superstore$Elapsed.Months/100) * 12 + superstore$Elapsed.Months %% 100

# Check structure again
str(superstore)

# First segment the whole dataset into the 21 subsets based on the Market and Segment column levels
i=1
v_df_sub = c()
v_df_sub_agg = c()
mkt_seg_profit_cv = data.frame(Market.Segment=character(),Profit.CV=double(), stringsAsFactors=FALSE)

for (mkt in levels(superstore$Market)) {
  for (seg in levels(superstore$Segment)) {
    if (seg == "Home Office") {
      seg1 = "Home_Office"
    } else {
      seg1 = seg
    }
    v_df_sub[i] = paste(mkt, seg1, sep = "_")
    assign(paste(mkt, seg1, sep = "_"), droplevels(subset(superstore, Market == mkt & Segment == seg)))
    i = i + 1
  }
}

# Check all new subset DFs that have been created
v_df_sub
# [1] "APAC_Consumer"      "APAC_Corporate"     "APAC_Home_Office"   "Africa_Consumer"    "Africa_Corporate"  
# [6] "Africa_Home_Office" "Canada_Consumer"    "Canada_Corporate"   "Canada_Home_Office" "EMEA_Consumer"     
# [11] "EMEA_Corporate"     "EMEA_Home_Office"   "EU_Consumer"        "EU_Corporate"       "EU_Home_Office"    
# [16] "LATAM_Consumer"     "LATAM_Corporate"    "LATAM_Home_Office"  "US_Consumer"        "US_Corporate"      
# [21] "US_Home_Office"    


for (j in 1:length(v_df_sub)) {
  v_df_sub_agg[j] = paste(v_df_sub[j], "Agg", sep = "_")
  assign(paste(v_df_sub[j], "Agg", sep = "_"), ddply(eval(parse(text = v_df_sub[j])),"Elapsed.Months", function(x) colSums(x[c("Profit", "Sales","Quantity")])))
  p_cv = cv(eval(parse(text = v_df_sub_agg[j]))$Profit)
  mkt_seg_profit_cv[j,] = list(v_df_sub[j],p_cv)
}

# Check all new aggregated DFs that have been created
v_df_sub_agg
# [1] "APAC_Consumer_Agg"      "APAC_Corporate_Agg"     "APAC_Home_Office_Agg"   "Africa_Consumer_Agg"   
# [5] "Africa_Corporate_Agg"   "Africa_Home_Office_Agg" "Canada_Consumer_Agg"    "Canada_Corporate_Agg"  
# [9] "Canada_Home_Office_Agg" "EMEA_Consumer_Agg"      "EMEA_Corporate_Agg"     "EMEA_Home_Office_Agg"  
# [13] "EU_Consumer_Agg"        "EU_Corporate_Agg"       "EU_Home_Office_Agg"     "LATAM_Consumer_Agg"    
# [17] "LATAM_Corporate_Agg"    "LATAM_Home_Office_Agg"  "US_Consumer_Agg"        "US_Corporate_Agg"      
# [21] "US_Home_Office_Agg"   

# Find the 2 most profitable and consistently profitable segments using CV
mkt_seg_profit_cv[order(mkt_seg_profit_cv$Profit.CV),][1:2,]$Market.Segment
# "EU_Consumer"
# "APAC_Consumer"

############################
###  Building the Model  ###
############################

############################
### EU_Consumer Analysis ###
############################

#**************************#
###  EU_Consumer SALES   ###
#**************************#

#Create a Time series for EU_Consumer sales
#plot the time series
EU_Consumer_Agg = EU_Consumer_Agg[order(EU_Consumer_Agg$Elapsed.Months),]
#Train data
EU_Consumer_Sales_indata = EU_Consumer_Agg[1:42, c("Elapsed.Months","Sales")]
#Test data
EU_Consumer_Sales_outdata = EU_Consumer_Agg[43:48, c("Elapsed.Months","Sales")]

EU_Consumer_Sales_TS = ts(EU_Consumer_Agg$Sales)
EU_Consumer_Sales_indata_ts = ts(EU_Consumer_Sales_indata$Sales)
plot(EU_Consumer_Sales_indata_ts)

#############################
### Smoothing the Series  ###
#############################
w = 1
EU_Consumer_Sales_indata_ts_smooth = stats::filter(EU_Consumer_Sales_indata_ts, 
                                             filter=rep(1/(2*w+1),(2*w+1)), 
                                             method='convolution', sides=2)

diff = EU_Consumer_Sales_indata_ts_smooth[w+2] - EU_Consumer_Sales_indata_ts_smooth[w+1]
for (i in seq(w,1,-1)) {
  EU_Consumer_Sales_indata_ts_smooth[i] = EU_Consumer_Sales_indata_ts_smooth[i+1] - diff
}

n = length(EU_Consumer_Sales_indata_ts)
diff = EU_Consumer_Sales_indata_ts_smooth[n-w] - EU_Consumer_Sales_indata_ts_smooth[n-w-1]
for (i in seq(n-w+1, n)) {
  EU_Consumer_Sales_indata_ts_smooth[i] = EU_Consumer_Sales_indata_ts_smooth[i-1] + diff
}

#Plot the smoothed time series
EU_Sales_timevals_in = EU_Consumer_Sales_indata$Elapsed.Months
lines(EU_Consumer_Sales_indata_ts_smooth, col="red", lwd=2)

#Let's convert the time series to a dataframe
EU_Consumer_Sales_indata_smoothed = as.data.frame(cbind(EU_Sales_timevals_in, as.vector(EU_Consumer_Sales_indata_ts_smooth)))
colnames(EU_Consumer_Sales_indata_smoothed) = c('Elapsed.Months', 'Sales')

#Now, let's fit a multiplicative model with trend and seasonality to the data
#Seasonality will be modeled using a sinusoid function
EU_Consumer_Sales_lmfit = lm(Sales ~ sin(0.5*Elapsed.Months) * poly(Elapsed.Months,3) + cos(0.5*Elapsed.Months) * poly(Elapsed.Months,3)
            + Elapsed.Months, data=EU_Consumer_Sales_indata_smoothed)

summary(EU_Consumer_Sales_lmfit)
accuracy(EU_Consumer_Sales_lmfit)     # MAPE 8.708967

EU_Sales_global_pred = predict(EU_Consumer_Sales_lmfit, Elapsed.Months=EU_Sales_timevals_in)
summary(EU_Sales_global_pred)
lines(EU_Sales_timevals_in, EU_Sales_global_pred, col='blue', lwd=2)

################################
### Classical Decomposition  ###
################################
#Locally predictable series, modelled as an ARMA series

EU_Sales_local_pred = EU_Consumer_Sales_indata_ts - EU_Sales_global_pred
plot(EU_Sales_local_pred, col='red', type = "l")
acf(EU_Sales_local_pred)
acf(EU_Sales_local_pred, type="partial")
par("mar") #5.1 4.1 4.1 2.1
par(mar=c(1,1,1,1))
EU_Sales_armafit = auto.arima(EU_Sales_local_pred)

tsdiag(EU_Sales_armafit)
par(mar=c(5.1,4.1,4.1,2.1))
EU_Sales_armafit 
# ARIMA(0,0,0) with zero mean 
# AIC=891.61   AICc=891.71   BIC=893.35

#Check if the residual series is white noise
EU_Sales_resi = EU_Sales_local_pred - fitted(EU_Sales_armafit)
adf.test(EU_Sales_resi,alternative = "stationary")
# Dickey-Fuller = -7.3166, Lag order = 3, p-value = 0.01

kpss.test(EU_Sales_resi)
# KPSS Level = 0.017855, Truncation lag parameter = 1, p-value = 0.1

#Now, let's evaluate the model using MAPE
#First, let's make a prediction for the last 6 months
EU_Sales_timevals_out = EU_Consumer_Sales_outdata$Elapsed.Months
EU_Sales_global_pred_out = predict(EU_Consumer_Sales_lmfit,data.frame(Elapsed.Months = EU_Sales_timevals_out))
EU_Sales_fcast = EU_Sales_global_pred_out

#Now, let's compare our prediction with the actual values, using MAPE
EU_Sales_MAPE_class_dec = accuracy(EU_Sales_fcast,EU_Consumer_Sales_outdata[,2])[5]
EU_Sales_MAPE_class_dec      # MAPE 92.95788

#Let's also plot the predictions along with original values, to
#get a visual feel of the fit

EU_Sales_class_dec_pred = c(ts(EU_Sales_global_pred),ts(EU_Sales_global_pred_out))
plot(EU_Consumer_Sales_TS, col = "black")
lines(EU_Sales_class_dec_pred, col = "red")

#######################
### AUTO ARIMA fit  ###
#######################

EU_Sales_autoarima = auto.arima(EU_Consumer_Sales_indata_ts)
EU_Sales_autoarima
# ARIMA(2,1,0) 
# AIC=897.67   AICc=898.32   BIC=902.81

par("mar") #5.1 4.1 4.1 2.1
par(mar=c(1,1,1,1))
tsdiag(EU_Sales_autoarima)
par(mar=c(5.1,4.1,4.1,2.1))
plot(EU_Sales_autoarima$x, col="black")
lines(fitted(EU_Sales_autoarima), col="red")

#Again, let's check if the residual series is white noise
EU_Sales_resi_auto_arima = EU_Consumer_Sales_indata_ts - fitted(EU_Sales_autoarima)

adf.test(EU_Sales_resi_auto_arima,alternative = "stationary")
# Dickey-Fuller = -4.3522, Lag order = 3, p-value = 0.01

kpss.test(EU_Sales_resi_auto_arima)
# KPSS Level = 0.05314, Truncation lag parameter = 1, p-value = 0.1

#Also, let's evaluate the model using MAPE
EU_Sales_fcast_auto_arima = predict(EU_Sales_autoarima, n.ahead = 6)

EU_Sales_MAPE_auto_arima = accuracy(EU_Sales_fcast_auto_arima$pred,EU_Consumer_Sales_outdata[,2])[5]
EU_Sales_MAPE_auto_arima
# 28.9226

#Lastly, let's plot the predictions along with original values, to
#get a visual feel of the fit

EU_Sales_auto_arima_pred = c(fitted(EU_Sales_autoarima),ts(EU_Sales_fcast_auto_arima$pred))
plot(EU_Consumer_Sales_TS, col = "black")
lines(EU_Sales_auto_arima_pred, col = "red")

#**************************#
### EU_Consumer QUANTITY ###
#**************************#

#Create a Time series for EU_Consumer Quantity
#plot the time series
#Train data
EU_Consumer_Quantity_indata = EU_Consumer_Agg[1:42, c("Elapsed.Months","Quantity")]
#Test data
EU_Consumer_Quantity_outdata = EU_Consumer_Agg[43:48, c("Elapsed.Months","Quantity")]

EU_Consumer_Quantity_TS = ts(EU_Consumer_Agg$Quantity)
EU_Consumer_Quantity_indata_ts = ts(EU_Consumer_Quantity_indata$Quantity)
plot(EU_Consumer_Quantity_indata_ts)

#############################
### Smoothing the Series  ###
#############################
w = 1
EU_Consumer_Quantity_indata_ts_smooth = stats::filter(EU_Consumer_Quantity_indata_ts, 
                                                      filter=rep(1/(2*w+1),(2*w+1)), 
                                                      method='convolution', sides=2)

diff = EU_Consumer_Quantity_indata_ts_smooth[w+2] - EU_Consumer_Quantity_indata_ts_smooth[w+1]
for (i in seq(w,1,-1)) {
  EU_Consumer_Quantity_indata_ts_smooth[i] = EU_Consumer_Quantity_indata_ts_smooth[i+1] - diff
}

n = length(EU_Consumer_Quantity_indata_ts)
diff = EU_Consumer_Quantity_indata_ts_smooth[n-w] - EU_Consumer_Quantity_indata_ts_smooth[n-w-1]
for (i in seq(n-w+1, n)) {
  EU_Consumer_Quantity_indata_ts_smooth[i] = EU_Consumer_Quantity_indata_ts_smooth[i-1] + diff
}

#Plot the smoothed time series
EU_Quantity_timevals_in = EU_Consumer_Quantity_indata$Elapsed.Months
lines(EU_Consumer_Quantity_indata_ts_smooth, col="red", lwd=2)

#Let's convert the time series to a dataframe
EU_Consumer_Quantity_indata_smoothed = as.data.frame(cbind(EU_Quantity_timevals_in, as.vector(EU_Consumer_Quantity_indata_ts_smooth)))
colnames(EU_Consumer_Quantity_indata_smoothed) = c('Elapsed.Months', 'Quantity')

#Now, let's fit a multiplicative model with trend and seasonality to the data
#Seasonality will be modeled using a sinusoid function
EU_Consumer_Quantity_lmfit = lm(Quantity ~ sin(0.5*Elapsed.Months) * poly(Elapsed.Months,3) + cos(0.5*Elapsed.Months) * poly(Elapsed.Months,3)
                                + Elapsed.Months, data=EU_Consumer_Quantity_indata_smoothed)

summary(EU_Consumer_Quantity_lmfit)
accuracy(EU_Consumer_Quantity_lmfit)     # MAPE 6.681782

EU_Quantity_global_pred = predict(EU_Consumer_Quantity_lmfit, Elapsed.Months=EU_Quantity_timevals_in)
summary(EU_Quantity_global_pred)
lines(EU_Quantity_timevals_in, EU_Quantity_global_pred, col='blue', lwd=2)

################################
### Classical Decomposition  ###
################################
#Locally predictable series, modelled as an ARMA series

EU_Quantity_local_pred = EU_Consumer_Quantity_indata_ts - EU_Quantity_global_pred
plot(EU_Quantity_local_pred, col='red', type = "l")
acf(EU_Quantity_local_pred)
acf(EU_Quantity_local_pred, type="partial")
par("mar") #5.1 4.1 4.1 2.1
par(mar=c(1,1,1,1))
EU_Quantity_armafit = auto.arima(EU_Quantity_local_pred)

tsdiag(EU_Quantity_armafit)
par(mar=c(5.1,4.1,4.1,2.1))
EU_Quantity_armafit 
# ARIMA(2,0,0) with zero mean 
# AIC=497.79   AICc=498.42   BIC=503

#Check if the residual series is white noise
EU_Quantity_resi = EU_Quantity_local_pred - fitted(EU_Quantity_armafit)
adf.test(EU_Quantity_resi,alternative = "stationary")
# Dickey-Fuller = -6.6825, Lag order = 3, p-value = 0.01

kpss.test(EU_Quantity_resi)
# KPSS Level = 0.023531, Truncation lag parameter = 1, p-value = 0.1

#Now, let's evaluate the model using MAPE
#First, let's make a prediction for the last 6 months
EU_Quantity_timevals_out = EU_Consumer_Quantity_outdata$Elapsed.Months
EU_Quantity_global_pred_out = predict(EU_Consumer_Quantity_lmfit,data.frame(Elapsed.Months = EU_Quantity_timevals_out))
EU_Quantity_fcast = EU_Quantity_global_pred_out

#Now, let's compare our prediction with the actual values, using MAPE
EU_Quantity_MAPE_class_dec = accuracy(EU_Quantity_fcast,EU_Consumer_Quantity_outdata[,2])[5]
EU_Quantity_MAPE_class_dec      # MAPE 30.39741

#Let's also plot the predictions along with original values, to
#get a visual feel of the fit

EU_Quantity_class_dec_pred = c(ts(EU_Quantity_global_pred),ts(EU_Quantity_global_pred_out))
plot(EU_Consumer_Quantity_TS, col = "black")
lines(EU_Quantity_class_dec_pred, col = "red")

#######################
### AUTO ARIMA fit  ###
#######################

EU_Quantity_autoarima = auto.arima(EU_Consumer_Quantity_indata_ts)
EU_Quantity_autoarima
# ARIMA(2,1,0) 
# AIC=529.8   AICc=530.44   BIC=534.94

par("mar") #5.1 4.1 4.1 2.1
par(mar=c(1,1,1,1))
tsdiag(EU_Quantity_autoarima)
par(mar=c(5.1,4.1,4.1,2.1))
plot(EU_Quantity_autoarima$x, col="black")
lines(fitted(EU_Quantity_autoarima), col="red")

#Again, let's check if the residual series is white noise
EU_Quantity_resi_auto_arima = EU_Consumer_Quantity_indata_ts - fitted(EU_Quantity_autoarima)

adf.test(EU_Quantity_resi_auto_arima,alternative = "stationary")
# Dickey-Fuller = -3.5969, Lag order = 3, p-value = 0.04521

kpss.test(EU_Quantity_resi_auto_arima)
# KPSS Level = 0.047939, Truncation lag parameter = 1, p-value = 0.1

#Also, let's evaluate the model using MAPE
EU_Quantity_fcast_auto_arima = predict(EU_Quantity_autoarima, n.ahead = 6)

EU_Quantity_MAPE_auto_arima = accuracy(EU_Quantity_fcast_auto_arima$pred,EU_Consumer_Quantity_outdata[,2])[5]
EU_Quantity_MAPE_auto_arima
# 30.13319

#Lastly, let's plot the predictions along with original values, to
#get a visual feel of the fit

EU_Quantity_auto_arima_pred = c(fitted(EU_Quantity_autoarima),ts(EU_Quantity_fcast_auto_arima$pred))
plot(EU_Consumer_Quantity_TS, col = "black")
lines(EU_Quantity_auto_arima_pred, col = "red")


##############################
### APAC_Consumer Analysis ###
##############################

#**************************#
#** APAC_Consumer SALES  **#
#**************************#

#Create a Time series for APAC_Consumer sales
#plot the time series
APAC_Consumer_Agg = APAC_Consumer_Agg[order(APAC_Consumer_Agg$Elapsed.Months),]
#Train data
APAC_Consumer_Sales_indata = APAC_Consumer_Agg[1:42, c("Elapsed.Months","Sales")]
#Test data
APAC_Consumer_Sales_outdata = APAC_Consumer_Agg[43:48, c("Elapsed.Months","Sales")]

APAC_Consumer_Sales_TS = ts(APAC_Consumer_Agg$Sales)
APAC_Consumer_Sales_indata_ts = ts(APAC_Consumer_Sales_indata$Sales)
plot(APAC_Consumer_Sales_indata_ts)

#############################
### Smoothing the Series  ###
#############################
w = 1
APAC_Consumer_Sales_indata_ts_smooth = stats::filter(APAC_Consumer_Sales_indata_ts, 
                                                     filter=rep(1/(2*w+1),(2*w+1)), 
                                                     method='convolution', sides=2)

diff = APAC_Consumer_Sales_indata_ts_smooth[w+2] - APAC_Consumer_Sales_indata_ts_smooth[w+1]
for (i in seq(w,1,-1)) {
  APAC_Consumer_Sales_indata_ts_smooth[i] = APAC_Consumer_Sales_indata_ts_smooth[i+1] - diff
}

n = length(APAC_Consumer_Sales_indata_ts)
diff = APAC_Consumer_Sales_indata_ts_smooth[n-w] - APAC_Consumer_Sales_indata_ts_smooth[n-w-1]
for (i in seq(n-w+1, n)) {
  APAC_Consumer_Sales_indata_ts_smooth[i] = APAC_Consumer_Sales_indata_ts_smooth[i-1] + diff
}

#Plot the smoothed time series
APAC_Sales_timevals_in = APAC_Consumer_Sales_indata$Elapsed.Months
lines(APAC_Consumer_Sales_indata_ts_smooth, col="red", lwd=2)

#Let's convert the time series to a dataframe
APAC_Consumer_Sales_indata_smoothed = as.data.frame(cbind(APAC_Sales_timevals_in, as.vector(APAC_Consumer_Sales_indata_ts_smooth)))
colnames(APAC_Consumer_Sales_indata_smoothed) = c('Elapsed.Months', 'Sales')

#Now, let's fit a multiplicative model with trend and seasonality to the data
#Seasonality will be modeled using a sinusoid function
APAC_Sales_Consumer_lmfit = lm(Sales ~ sin(0.5*Elapsed.Months) * poly(Elapsed.Months,3) + cos(0.5*Elapsed.Months) * poly(Elapsed.Months,3)
                         + Elapsed.Months, data=APAC_Consumer_Sales_indata_smoothed)

summary(APAC_Sales_Consumer_lmfit)
accuracy(APAC_Sales_Consumer_lmfit)      # MAPE 9.265887

APAC_Sales_global_pred = predict(APAC_Sales_Consumer_lmfit, Elapsed.Months=APAC_Sales_timevals_in)
summary(APAC_Sales_global_pred)
lines(APAC_Sales_timevals_in, APAC_Sales_global_pred, col='blue', lwd=2)

################################
### Classical Decomposition  ###
################################
#Locally predictable series, modelled as an ARMA series

APAC_Sales_local_pred = APAC_Consumer_Sales_indata_ts - APAC_Sales_global_pred
plot(APAC_Sales_local_pred, col='red', type = "l")
acf(APAC_Sales_local_pred)
acf(APAC_Sales_local_pred, type="partial")
par("mar") #5.1 4.1 4.1 2.1
par(mar=c(1,1,1,1))
APAC_Sales_armafit = auto.arima(APAC_Sales_local_pred)

tsdiag(APAC_Sales_armafit)
par(mar=c(5.1,4.1,4.1,2.1))
APAC_Sales_armafit 
# ARIMA(0,0,0) with zero mean 
# AIC=889.49   AICc=889.59   BIC=891.23

#Check if the residual series is white noise
APAC_Sales_resi = APAC_Sales_local_pred - fitted(APAC_Sales_armafit)
adf.test(APAC_Sales_resi,alternative = "stationary")
# Dickey-Fuller = -6.8673, Lag order = 3, p-value = 0.01

kpss.test(APAC_Sales_resi)
# KPSS Level = 0.021731, Truncation lag parameter = 1, p-value = 0.1

#Now, let's evaluate the model using MAPE
#First, let's make a prediction for the last 6 months
APAC_Sales_timevals_out = APAC_Consumer_Sales_outdata$Elapsed.Months
APAC_Sales_global_pred_out = predict(APAC_Sales_Consumer_lmfit,data.frame(Elapsed.Months = APAC_Sales_timevals_out))
APAC_Sales_fcast = APAC_Sales_global_pred_out

#Now, let's compare our prediction with the actual values, using MAPE
APAC_Sales_MAPE_class_dec = accuracy(APAC_Sales_fcast,APAC_Consumer_Sales_outdata[,2])[5]
APAC_Sales_MAPE_class_dec     # MAPE 31.07429

#Let's also plot the predictions along with original values, to
#get a visual feel of the fit

APAC_Sales_class_dec_pred = c(ts(APAC_Sales_global_pred),ts(APAC_Sales_global_pred_out))
plot(APAC_Consumer_Sales_TS, col = "black")
lines(APAC_Sales_class_dec_pred, col = "red")

#######################
### AUTO ARIMA fit  ###
#######################

APAC_Sales_autoarima = auto.arima(APAC_Consumer_Sales_indata_ts)
APAC_Sales_autoarima
# ARIMA(0,1,1) 
# AIC=898.23   AICc=898.55   BIC=901.66

par("mar") #5.1 4.1 4.1 2.1
par(mar=c(1,1,1,1))
tsdiag(APAC_Sales_autoarima)
par(mar=c(5.1,4.1,4.1,2.1))
plot(APAC_Sales_autoarima$x, col="black")
lines(fitted(APAC_Sales_autoarima), col="red")

#Again, let's check if the residual series is white noise
APAC_Sales_resi_auto_arima = APAC_Consumer_Sales_indata_ts - fitted(APAC_Sales_autoarima)

adf.test(APAC_Sales_resi_auto_arima,alternative = "stationary")
# Dickey-Fuller = -4.2563, Lag order = 3, p-value = 0.01

kpss.test(APAC_Sales_resi_auto_arima)
# KPSS Level = 0.042734, Truncation lag parameter = 1, p-value = 0.1

#Also, let's evaluate the model using MAPE
APAC_Sales_fcast_auto_arima = predict(APAC_Sales_autoarima, n.ahead = 6)

APAC_Sales_MAPE_auto_arima = accuracy(APAC_Sales_fcast_auto_arima$pred,APAC_Consumer_Sales_outdata[,2])[5]
APAC_Sales_MAPE_auto_arima       # 27.68952

#Lastly, let's plot the predictions along with original values, to
#get a visual feel of the fit

APAC_Sales_auto_arima_pred = c(fitted(APAC_Sales_autoarima),ts(APAC_Sales_fcast_auto_arima$pred))
plot(APAC_Consumer_Sales_TS, col = "black")
lines(APAC_Sales_auto_arima_pred, col = "red")


#*****************************#
#** APAC_Consumer QUANTITY  **#
#*****************************#

#Create a Time series for APAC_Consumer Quantity
#plot the time series
#Train data
APAC_Consumer_Quantity_indata = APAC_Consumer_Agg[1:42, c("Elapsed.Months","Quantity")]
#Test data
APAC_Consumer_Quantity_outdata = APAC_Consumer_Agg[43:48, c("Elapsed.Months","Quantity")]

APAC_Consumer_Quantity_TS = ts(APAC_Consumer_Agg$Quantity)
APAC_Consumer_Quantity_indata_ts = ts(APAC_Consumer_Quantity_indata$Quantity)
plot(APAC_Consumer_Quantity_indata_ts)

#############################
### Smoothing the Series  ###
#############################
w = 1
APAC_Consumer_Quantity_indata_ts_smooth = stats::filter(APAC_Consumer_Quantity_indata_ts, 
                                                        filter=rep(1/(2*w+1),(2*w+1)), 
                                                        method='convolution', sides=2)

diff = APAC_Consumer_Quantity_indata_ts_smooth[w+2] - APAC_Consumer_Quantity_indata_ts_smooth[w+1]
for (i in seq(w,1,-1)) {
  APAC_Consumer_Quantity_indata_ts_smooth[i] = APAC_Consumer_Quantity_indata_ts_smooth[i+1] - diff
}

n = length(APAC_Consumer_Quantity_indata_ts)
diff = APAC_Consumer_Quantity_indata_ts_smooth[n-w] - APAC_Consumer_Quantity_indata_ts_smooth[n-w-1]
for (i in seq(n-w+1, n)) {
  APAC_Consumer_Quantity_indata_ts_smooth[i] = APAC_Consumer_Quantity_indata_ts_smooth[i-1] + diff
}

#Plot the smoothed time series
APAC_Quantity_timevals_in = APAC_Consumer_Quantity_indata$Elapsed.Months
lines(APAC_Consumer_Quantity_indata_ts_smooth, col="red", lwd=2)

#Let's convert the time series to a dataframe
APAC_Consumer_Quantity_indata_smoothed = as.data.frame(cbind(APAC_Quantity_timevals_in, as.vector(APAC_Consumer_Quantity_indata_ts_smooth)))
colnames(APAC_Consumer_Quantity_indata_smoothed) = c('Elapsed.Months', 'Quantity')

#Now, let's fit a multiplicative model with trend and seasonality to the data
#Seasonality will be modeled using a sinusoid function
APAC_Quantity_Consumer_lmfit = lm(Quantity ~ sin(0.5*Elapsed.Months) * poly(Elapsed.Months,3) + cos(0.5*Elapsed.Months) * poly(Elapsed.Months,3)
                                  + Elapsed.Months, data=APAC_Consumer_Quantity_indata_smoothed)

summary(APAC_Quantity_Consumer_lmfit)
accuracy(APAC_Quantity_Consumer_lmfit)      # MAPE 10.26704

APAC_Quantity_global_pred = predict(APAC_Quantity_Consumer_lmfit, Elapsed.Months=APAC_Quantity_timevals_in)
summary(APAC_Quantity_global_pred)
lines(APAC_Quantity_timevals_in, APAC_Quantity_global_pred, col='blue', lwd=2)

################################
### Classical Decomposition  ###
################################
#Locally predictable series, modelled as an ARMA series

APAC_Quantity_local_pred = APAC_Consumer_Quantity_indata_ts - APAC_Quantity_global_pred
plot(APAC_Quantity_local_pred, col='red', type = "l")
acf(APAC_Quantity_local_pred)
acf(APAC_Quantity_local_pred, type="partial")
par("mar") #5.1 4.1 4.1 2.1
par(mar=c(1,1,1,1))
APAC_Quantity_armafit = auto.arima(APAC_Quantity_local_pred)

tsdiag(APAC_Quantity_armafit)
par(mar=c(5.1,4.1,4.1,2.1))
APAC_Quantity_armafit 
# ARIMA(0,0,0) with zero mean 
# AIC=509.42   AICc=509.52   BIC=511.16

#Check if the residual series is white noise
APAC_Quantity_resi = APAC_Quantity_local_pred - fitted(APAC_Quantity_armafit)
adf.test(APAC_Quantity_resi,alternative = "stationary")
# Dickey-Fuller = -7.4893, Lag order = 3, p-value = 0.01

kpss.test(APAC_Quantity_resi)
# KPSS Level = 0.01898, Truncation lag parameter = 1, p-value = 0.1

#Now, let's evaluate the model using MAPE
#First, let's make a prediction for the last 6 months
APAC_Quantity_timevals_out = APAC_Consumer_Quantity_outdata$Elapsed.Months
APAC_Quantity_global_pred_out = predict(APAC_Quantity_Consumer_lmfit,data.frame(Elapsed.Months = APAC_Quantity_timevals_out))
APAC_Quantity_fcast = APAC_Quantity_global_pred_out

#Now, let's compare our prediction with the actual values, using MAPE
APAC_Quantity_MAPE_class_dec = accuracy(APAC_Quantity_fcast,APAC_Consumer_Quantity_outdata[,2])[5]
APAC_Quantity_MAPE_class_dec     # MAPE 62.10289

#Let's also plot the predictions along with original values, to
#get a visual feel of the fit

APAC_Quantity_class_dec_pred = c(ts(APAC_Quantity_global_pred),ts(APAC_Quantity_global_pred_out))
plot(APAC_Consumer_Quantity_TS, col = "black")
lines(APAC_Quantity_class_dec_pred, col = "red")

#######################
### AUTO ARIMA fit  ###
#######################

APAC_Quantity_autoarima = auto.arima(APAC_Consumer_Quantity_indata_ts)
APAC_Quantity_autoarima
# ARIMA(0,1,0) 
# AIC=534.14   AICc=534.24   BIC=535.85

par("mar") #5.1 4.1 4.1 2.1
par(mar=c(1,1,1,1))
tsdiag(APAC_Quantity_autoarima)
par(mar=c(5.1,4.1,4.1,2.1))
plot(APAC_Quantity_autoarima$x, col="black")
lines(fitted(APAC_Quantity_autoarima), col="red")

#Again, let's check if the residual series is white noise
APAC_Quantity_resi_auto_arima = APAC_Consumer_Quantity_indata_ts - fitted(APAC_Quantity_autoarima)

adf.test(APAC_Quantity_resi_auto_arima,alternative = "stationary")
# Dickey-Fuller = -4.3326, Lag order = 3, p-value = 0.01

kpss.test(APAC_Quantity_resi_auto_arima)
# KPSS Level = 0.031535, Truncation lag parameter = 1, p-value = 0.1

#Also, let's evaluate the model using MAPE
APAC_Quantity_fcast_auto_arima = predict(APAC_Quantity_autoarima, n.ahead = 6)

APAC_Quantity_MAPE_auto_arima = accuracy(APAC_Quantity_fcast_auto_arima$pred,APAC_Consumer_Quantity_outdata[,2])[5]
APAC_Quantity_MAPE_auto_arima       # 26.24458

#Lastly, let's plot the predictions along with original values, to
#get a visual feel of the fit

APAC_Quantity_auto_arima_pred = c(fitted(APAC_Quantity_autoarima),ts(APAC_Quantity_fcast_auto_arima$pred))
plot(APAC_Consumer_Quantity_TS, col = "black")
lines(APAC_Quantity_auto_arima_pred, col = "red")

