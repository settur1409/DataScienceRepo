Sys.setenv(SPARK_HOME = "/usr/local/spark")
library(SparkR, lib.loc = c(file.path(Sys.getenv("SPARK_HOME"),"R","lib")))
sparkR.session(master = "yarn")

# load SparkR
library(SparkR)


#Merged Data

mergedData <- SparkR::read.df("/common_folder/nyc_parking/", "CSV", header="true")

parking_df <- withColumn(mergedData,"date_issued",unix_timestamp(mergedData$`Issue Date`, "MM/dd/yyyy"))

parking_df$date_issued <- cast(parking_df$date_issued, "timestamp")

str(parking_df)

createOrReplaceTempView(parking_df, "parking_tbl")


parking_final <- SparkR::sql("SELECT * FROM parking_tbl WHERE year(date_issued)==2017
                             OR year(date_issued)==2016 OR year(date_issued)==2015")

head(parking_final)

createOrReplaceTempView(parking_final, "parking_final_tbl")

str(parking_final)
#Cross checking for correct years

head(sql("SELECT distinct(year(date_issued)) FROM parking_final_tbl"))

##   year(CAST(date_issued AS DATE))                                               
##              2015
##              2016
##              2017


##################################################################
##################  Examine the data ############################
##################################################################

### 1. Find total number of tickets for each year.

head(sql("SELECT year(date_issued) as year_issued, count(*) as ticket_count 
         FROM parking_final_tbl GROUP BY year(date_issued)"))

##    year_issued ticket_count                                                      
##        2015     11738259
##        2016     10241012
##        2017      5433018

### 2. Find out how many unique states the cars which got parking tickets came from.

head(sql("SELECT count(distinct(`Registration State`)) FROM parking_final_tbl"))

## count(DISTINCT Registration State)                                            
##              69


### 3. Some parking tickets don’t have addresses on them, which is cause for concern. 
###    Find out how many such tickets there are.

head(sql("SELECT count(*) FROM parking_final_tbl
         WHERE `Violation Location` IS NULL"))

##  count(1)                                                                      
##  4742645

####################################################################
####################  Aggregation tasks   ##########################
####################################################################

## 1. How often does each violation code occur? (frequency of violation codes - find the top 5)

head(sql("SELECT `Violation Code`, count(*) AS count FROM parking_final_tbl
         GROUP BY `Violation Code` ORDER BY count(*) DESC LIMIT 5"))

## Violation Code   count                                                        
##      21          3869197
##      36          3111439
##      38          2952526
##      14          2286502
##      37          1699486


## 2. How often does each vehicle body type get a parking ticket? 
##    How about the vehicle make? (find the top 5 for both)

head(sql("SELECT `Vehicle Body Type`, count(*) AS count FROM parking_final_tbl
         GROUP BY `Vehicle Body Type` ORDER BY count(*) DESC LIMIT 5"))

## Vehicle Body Type     count                                                     
##        SUBN          9100113
##        4DSD          7768379
##        VAN           3809438
##        DELV          1903396
##        SDN           1097903

head(sql("SELECT `Vehicle Make`, count(*) AS count FROM parking_final_tbl
         GROUP BY `Vehicle Make` ORDER BY count(*) DESC LIMIT 5"))

##Vehicle Make   count                                                          
##    FORD      3368392
##    TOYOT     2984933
##    HONDA     2650193
##    NISSA     2213081
##    CHEVR     1924180

## 3. A precinct is a police station that has a certain zone of the city under its command. 
##    Find the (5 highest) frequencies of:
##    1.  Violating Precincts (this is the precinct of the zone where the violation occurred). 
##        Using this, can you make any insights for parking violations in any specific areas of the city? 

##head(sql("SELECT `Violation Precinct`,  count(*) AS count FROM parking_final_tbl
##         GROUP BY `Violation Precinct` ORDER BY count(*) DESC LIMIT 5"))

head(sql("SELECT `Violation Precinct`,  count(*) AS count, `Street Name` FROM parking_final_tbl
         GROUP BY `Violation Precinct`, `Street Name` ORDER BY count(*) DESC LIMIT 5"))

##Violation Precinct  count          Street Name                                
##                 19 186350              3rd Ave
##                 19 148801          Madison Ave
##                 19 126939        Lexington Ave
##                 19 113409              1st Ave
##                112 101397          Queens Blvd

##   2. Issuing Precincts (this is the precinct that issued the ticket)

head(sql("SELECT `Issuer Precinct`, count(*) AS count FROM parking_final_tbl
         GROUP BY `Issuer Precinct` ORDER BY count(*) DESC LIMIT 5"))

##Issuer Precinct   count                                                       
##               0 5451818
##              19 1372464
##              14  870724
##              18  831708
##               1  781152


## 4. Find the violation code frequency across 3 precincts which have issued the most number of tickets - 
##    do these precinct zones have an exceptionally high frequency of certain violation codes? 
##    Are these codes common across precincts?

issuer_violations <- SparkR::sql("SELECT `Issuer Precinct`, `Violation Code`, count(*) AS count 
                                 FROM parking_final_tbl WHERE `Issuer Precinct` IN (0, 19, 14) 
                                 GROUP BY `Issuer Precinct`,`Violation Code` ORDER BY count(*) DESC")


issuer_df <- collect(issuer_violations)
hist <- histogram(issuer_violations, issuer_violations$`Violation Code`)
require(ggplot2)
ggplot(hist, aes(x = centroids, y = counts)) + geom_bar(stat = "identity") + xlab("violation codes") + ylab("count")
head(issuer_df)
##    Issuer Precinct Violation Code   count
##               0             36     3111438
##               0              7     1285099
##               0             21     613770
##               0              5     319360
##              19             38     201237
##              19             37     193419

View(issuer_df)

#Violation code frequency across Issuer Precinct 0
##head(sql("SELECT `Violation Code`, count(*) AS count 
##         FROM parking_final_tbl WHERE `Issuer Precinct`==0 
##         GROUP BY `Violation Code` ORDER BY count(*) DESC LIMIT 5"))

head(sql("SELECT `Violation Code`, count(*) AS count 
         FROM parking_final_tbl WHERE `Issuer Precinct`==0 
         GROUP BY `Violation Code` ORDER BY count(*) DESC"))

##  Violation Code   count                                                        
##             36   3111438
##              7   1285099
##             21   613770
##              5   319360
##             66   19635
##             14   15692

#Violation code frequency across Issuer Precincts 19
head(sql("SELECT `Violation Code`, count(*) AS count 
         FROM parking_final_tbl WHERE `Issuer Precinct`==19 
         GROUP BY `Violation Code` ORDER BY count(*) DESC"))

## Violation Code  count                                                         
##             38 201237
##             37 193419
##             46 188145
##             14 153711
##             21 142611
##             16 116448

#Violation code frequency across Issuer Precincts 14
head(sql("SELECT `Violation Code`, count(*) AS count 
         FROM parking_final_tbl WHERE `Issuer Precinct`==14
         GROUP BY `Violation Code` ORDER BY count(*) DESC"))

##  Violation Code  count                                                         
##             14   178877
##             69   171058
##             31   98615
##             47   70904
##             42   60347
##             46   29377

## Common violations among precincts

precinct_0 <- SparkR::sql("SELECT `Violation Code`, count(*) AS count 
         FROM parking_final_tbl WHERE `Issuer Precinct`==0 
                          GROUP BY `Violation Code` ORDER BY count(*) DESC ")

createOrReplaceTempView(precinct_0, "precinct_0_tbl")

precinct_19 <- SparkR::sql("SELECT `Violation Code`, count(*) AS count 
                           FROM parking_final_tbl WHERE `Issuer Precinct`==19 
                           GROUP BY `Violation Code` ORDER BY count(*) DESC")

createOrReplaceTempView(precinct_19, "precinct_19_tbl")

precinct_14 <- SparkR::sql("SELECT `Violation Code`, count(*) AS count 
                           FROM parking_final_tbl WHERE `Issuer Precinct`==14 
                           GROUP BY `Violation Code` ORDER BY count(*) ")

createOrReplaceTempView(precinct_14, "precinct_14_tbl")


common_violations <- SparkR::sql("SELECT precinct_0_tbl.`Violation Code` FROM precinct_0_tbl INNER JOIN precinct_19_tbl
          ON precinct_0_tbl.`Violation Code`= precinct_19_tbl.`Violation Code`
          INNER JOIN precinct_14_tbl ON
          precinct_0_tbl.`Violation Code`= precinct_14_tbl.`Violation Code`
          ORDER BY precinct_0_tbl.`Violation Code` ")


common_violations_df <- collect(common_violations)

View(common_violations_df)
head(common_violations_df) 

common_violations_hist <- histogram(common_violations, common_violations$`Violation Code`)
require(ggplot2)
ggplot(common_violations_hist, aes(x = centroids, y = counts)) + geom_bar(stat = "identity") + xlab("violation codes") + ylab("count")
##Violation Code
##              0
##              1
##             10
##             11
##             12
##             13

## 5. You’d want to find out the properties of parking violations across different times of the day:

##    1. The Violation Time field is specified in a strange format. 
##       Find a way to make this into a time attribute that you can use to divide into groups.

#Properties of parking violations across different times of the day

violation_time <- SparkR::sql("SELECT *, LEFT(`Violation Time`, 2) as violation_hour, 
                               CASE WHEN (`Violation Time` like '%A%') THEN 'A'
                                    WHEN (`Violation Time` like '%P%') THEN 'P'
                                    END as am_pm
                               FROM parking_final_tbl
                               WHERE `Violation Time` IS NOT NULL")


##violation_time <- SparkR::sql("SELECT *, CASE  
##                                      WHEN (`Violation Time` like '%A%')  THEN 'A'
##                                      WHEN (`Violation Time` like '%P%') THEN 'P'
##                                      END as am_pm FROM parking_final_tbl
##                                      WHERE `Violation Time` IS NOT NULL")

head(violation_time)
str(violation_time)

require(SparkR)

violation_time$violation_time <- cast(violation_time$violation_hour, "int")

violation_time <- fillna(violation_time, 0)
am_violation <- filter(violation_time, violation_time$am_pm == 'A')
pm_violation <- filter(violation_time, violation_time$am_pm == 'P')
str(am_violation)
str(pm_violation)

pm_violation$violation_time <- pm_violation$violation_time + 12
createOrReplaceTempView(violation_time, "violation_time_tlb")

createOrReplaceTempView(am_violation, "am_violation_tbl")
createOrReplaceTempView(pm_violation, "pm_violation_tbl")

violation_time_final <- SparkR::sql("SELECT * FROM pm_violation_tbl UNION ALL
                                    SELECT * FROM am_violation_tbl")

createOrReplaceTempView(violation_time_final, "violation_time_tbl")

## filled all the NA's with zeros. 
##parking_final <- fillna(parking_final, 0)

str(violation_time_final)

head(sql("SELECT count(*) FROM parking_final_tbl"))

head(sql("SELECT count(*) FROM parking_final_tbl WHERE `Violation Time` IS NULL"))

## count(1)                                                                      
##  5050

## 2. Find a way to deal with missing values, if any.
## TODO --> Find a way to deal with missing values, if any.

violation_time <- fillna(violation_time$violation_time, 12)
violation_null_entries = filter(violation_time, isNull(violation_time$`violation_time`))
createOrReplaceTempView(violation_null_entries, "violation_null_tbl")

head(sql("SELECT count(*) FROM violation_time_tbl"))
## count(1)                                                                      
## 27407209

head(sql("SELECT distinct(am_pm) FROM violation_time_tbl"))
## am_pm                                                                         
##     A
##     P

## 3. Divide 24 hours into 6 equal discrete bins of time. The intervals you choose are at your discretion. 
##    For each of these groups,  find the 3 most commonly occurring violations

time_bins <- SparkR::sql("SELECT *, CASE  
                                      WHEN (violation_time >= 0  and violation_time < 6)  THEN 0
                                      WHEN (violation_time >= 6  and violation_time < 12) THEN 6
                                      WHEN (violation_time >= 12  and violation_time < 18) THEN 12
                                      ELSE 18 END  
                                      as time_bin FROM violation_time_tbl")

hist <- histogram(time_bins, time_bins$time_bin)
ggplot(hist, aes(x = centroids, y = counts)) + geom_bar(stat = "identity") + xlab("voilation in bins") + ylab("counts")
str(time_bins)

createOrReplaceTempView(time_bins, "time_bin_tbl")


time_bin_violations <- SparkR::sql("SELECT time_bin, `Violation Code`, count(*) AS ticket_count 
                                   FROM time_bin_tbl
                                   GROUP BY time_bin,`Violation Code` ORDER BY count(*) DESC")

time_df <- collect(time_bin_violations)

View(time_df)
head(time_df)

## time_bin Violation Code ticket_count
##        6             21      3311534
##        6             36      1699709
##       12             38      1412138
##       12             37      1089097
##        6             14      1031444
##        6             38      1004159


createOrReplaceTempView(time_bin_violations, "time_violation_tbl")

#Violation Code commonly occuring for time bin 0-6

head(sql("SELECT `Violation Code`, ticket_count 
         FROM time_violation_tbl WHERE time_bin == 0
         order by ticket_count desc LIMIT 3"))

## Violation Code ticket_count                                                   
##             21       186586
##             40       162846
##             14       116802


#Violation Code commonly occuring for time bin 6-12

head(sql("SELECT `Violation Code`, ticket_count 
         FROM time_violation_tbl WHERE time_bin == 6
         order by ticket_count desc LIMIT 3"))

## Violation Code ticket_count                                                   
##             21      3311534
##             36      1699709
##             14      1031444


#Violation Code commonly occuring for time bin 12-18

head(sql("SELECT `Violation Code`, ticket_count 
         FROM time_violation_tbl WHERE time_bin == 12
         order by ticket_count desc LIMIT 3"))

## Violation Code ticket_count                                                   
##             38      1412138
##             37      1089097
##             36       969255

#Violation Code commonly occuring for time bin 18-24

head(sql("SELECT `Violation Code`, ticket_count 
         FROM time_violation_tbl WHERE time_bin == 18
         order by ticket_count desc LIMIT 3"))

## Violation Code ticket_count                                                   
##             38       534316
##             36       442462
##              7       383927

#Time bins for 3 most commonly occurring violations

head(sql("SELECT `Violation Code`, count(*) AS count FROM parking_final_tbl
         GROUP BY `Violation Code` ORDER BY count(*) DESC LIMIT 3"))

## Violation Code   count                                                        
##             21 3869197
##             36 3111439
##             38 2952526

## 4. Now, try another direction. For the 3 most commonly occurring violation codes, 
##    find the most common times of day (in terms of the bins from the previous part)

violations_bin <- SparkR::sql("SELECT time_bin, count(*) AS ticket_count 
                              FROM time_bin_tbl WHERE `Violation Code` IN (21, 36, 38)
                              GROUP BY time_bin ORDER BY count(*) DESC")


violationsbin_df <- collect(violations_bin)

head(violationsbin_df)
##time_bin ticket_count
##        6      6015402
##       12      2403023
##       18      1325423
##        0       188253

View(violationsbin_df)

## 6. Let’s try and find some seasonality in this data
##    1. First, divide the year into some number of seasons, and find frequencies of tickets for each season.

season_bins <- SparkR::sql("SELECT *, CASE  
                                          WHEN (month(date_issued) >= 1  and month(date_issued) <=3)  THEN 1
                                          WHEN (month(date_issued) >= 4  and month(date_issued) <= 6)  THEN 2
                                          WHEN (month(date_issued) >= 7  and month(date_issued) <= 9)  THEN 3
                                          WHEN (month(date_issued) >= 10  and month(date_issued) <= 12)  THEN 4
                                          END  as season_bin FROM violation_time_tbl")

createOrReplaceTempView(season_bins, "season_tbl")

#Frequency of tickets for season 1

head(sql("SELECT count(*) AS ticket_count FROM season_tbl 
         WHERE season_bin == 1"))
## ticket_count                                                                  
##      8420705

#Frequency of tickets for season 2

head(sql("SELECT count(*) AS ticket_count FROM season_tbl 
         WHERE season_bin == 2"))
## ticket_count                                                                  
##      8346848

#Frequency of tickets for season 3

head(sql("SELECT count(*) AS ticket_count FROM season_tbl 
         WHERE season_bin == 3"))
## ticket_count                                                                  
##      5191122

#Frequency of tickets for season 4

head(sql("SELECT count(*) AS ticket_count FROM season_tbl 
         WHERE season_bin == 4"))

## ticket_count                                                                  
##     5448534

#Top 3 violations for season 1

head(sql("SELECT `Violation Code`, count(*) AS count FROM season_tbl 
         WHERE season_bin == 1
         GROUP BY `Violation Code` ORDER BY count(*) DESC LIMIT 3"))

##Violation Code   count                                                        
##             21 1094072
##             38 1015414
##             36  909527

#Top 3 violations for season 2

head(sql("SELECT `Violation Code`, count(*) AS count FROM season_tbl 
         WHERE season_bin == 2
         GROUP BY `Violation Code` ORDER BY count(*) DESC LIMIT 3"))

##Violation Code   count                                                        
##             21 1208078
##             36  901730
##             38  848707


#Top 3 violations for season 3

head(sql("SELECT `Violation Code`, count(*) AS count FROM season_tbl 
         WHERE season_bin == 3
         GROUP BY `Violation Code` ORDER BY count(*) DESC LIMIT 3"))

##Violation Code  count                                                         
##             21 789274
##             38 550330
##             14 436517
#Top 3 violations for season 4

head(sql("SELECT `Violation Code`, count(*) AS count FROM season_tbl 
         WHERE season_bin == 4
         GROUP BY `Violation Code` ORDER BY count(*) DESC LIMIT 3"))

## Violation Code  count                                                         
##             36 876558
##             21 776971
##             38 537817

## 7. The fines collected from all the parking violation constitute a revenue source for the NYC police department. 
##    Let’s take an example of estimating that for the 3 most commonly occurring codes.


#Top 3 most common violation codes
head(sql("SELECT `Violation Code`, count(*) AS count FROM parking_final_tbl
         GROUP BY `Violation Code` ORDER BY count(*) DESC LIMIT 3"))

##Violation Code   count                                                        
##             21 3869197
##             36 3111439
##             38 2952526

#Average cost for Code 21 violations is $55 (65+45/2)
#Average cost for Code 36 violations is $50 (50+50/2)
#Average cost for Code 38 violations is $50 (65+35/2)

fine_amount <- SparkR::sql("SELECT *,
                   CASE  WHEN `Violation Code` == 21 THEN 55
                   WHEN `Violation Code` == 36 THEN 50
                   WHEN `Violation Code` == 38 THEN 50
                   ELSE 1 
                   END  as fine_amt FROM parking_final_tbl")

fine_df <- filter(fine_amount, fine_amount$fine_amt != 1)

createOrReplaceTempView(fine_df, "fine_tbl")

head(sql("SELECT `Violation Code`, count(*) as ticket_count,
          sum(fine_amt) as total_fine_amt FROM fine_tbl
          GROUP BY `Violation Code`"))

## Violation Code ticket_count total_fine_amt                                    
##             38      2952526      147626300
##             36      3111439      155571950
##             21      3869197      212805835
